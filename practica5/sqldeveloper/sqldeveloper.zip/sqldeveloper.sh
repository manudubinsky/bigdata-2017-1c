#!/bin/sh
java -jar sqldeveloper.jar
